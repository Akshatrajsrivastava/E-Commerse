export interface Deal {
    name: string;
    price: string;
    originalPrice: string;
    image: string;
}